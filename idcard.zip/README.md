Kartu pelajar dengan codeigniter
1. HTML
2. Javascript

Fitur
1. Upload data siswa
2. QR Generator
3. Cetak/print kartu
4. Management sekolah
5. Upload logo, dinas, stempel, tanda tangan
6. Upload background kartu
7. 2 Layout kartu
